import React from 'react';

export default function TiktokYoutubePreset() {
  return (
    <div className="tiktok-youtube-preset-container">
      <h2>Preset TikTok/YouTube</h2>
      <p>Đây là nơi bạn sẽ thêm chức năng preset TikTok/YouTube.</p>
    </div>
  );
}