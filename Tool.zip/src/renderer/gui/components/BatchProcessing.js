import React from 'react';

export default function BatchProcessing() {
  return (
    <div className="batch-processing-container">
      <h2>Xử lý Hàng loạt</h2>
      <p>Đây là nơi bạn sẽ thêm chức năng xử lý hàng loạt.</p>
    </div>
  );
}