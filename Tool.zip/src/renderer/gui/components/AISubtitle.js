import React from 'react';

export default function AISubtitle() {
  return (
    <div className="ai-subtitle-container">
      <h2>Phụ đề AI</h2>
      <p>Đây là nơi bạn sẽ thêm chức năng phụ đề AI.</p>
    </div>
  );
}