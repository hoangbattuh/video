import React from 'react';

export default function RemoveAudio() {
  return (
    <div className="remove-audio-container">
      <h2>Xóa Âm thanh</h2>
      <p>Đây là nơi bạn sẽ thêm chức năng xóa âm thanh.</p>
    </div>
  );
}