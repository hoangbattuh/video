# Video Editor Pro

Ứng dụng chỉnh sửa video chuyên nghiệp với các tính năng:
- Cắt video
- Ghép video
- Xóa âm thanh

## Cấu trúc dự án
- `main.py`: Điểm khởi động ứng dụng
- `gui/`: Giao diện người dùng
- `video_processing/`: Xử lý video
- `requirements.txt`: Thư viện phụ thuộc
- `README.md`: Tài liệu dự án